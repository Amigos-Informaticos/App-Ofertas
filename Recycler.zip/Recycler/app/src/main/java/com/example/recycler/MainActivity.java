package com.example.recycler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.widget.SearchView;

import com.example.recycler.adaptador.RecyclerAdapter;
import com.example.recycler.model.ItemList;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RecyclerAdapter.RecyclerItemClick, SearchView.OnQueryTextListener {
    private RecyclerView rvLista;
    private SearchView svSearch;
    private RecyclerAdapter adapter;
    private List<ItemList> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        initValues();
        initListener();
    }

    private void initViews(){
        rvLista = findViewById(R.id.rvLista);
        svSearch = findViewById(R.id.svSearch);
    }

    private void initValues() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        rvLista.setLayoutManager(manager);

        items = getItems();
        adapter = new RecyclerAdapter(items, this);
        rvLista.setAdapter(adapter);
    }

    private void initListener() {
        svSearch.setOnQueryTextListener(this);
    }

    private List<ItemList> getItems() {
        List<ItemList> itemLists = new ArrayList<>();
        ItemList itemList1 = new ItemList("Tenis blancos", "Tenis adidas balncos", R.drawable.saga_broly);
        itemList1.setPuntuacion(200);
        itemList1.setPrecio(500);
        itemList1.setFechaFin("23/05/2021");

        ItemList itemList2 = new ItemList("Camisa negra", "Camisa levis negra",R.drawable.ssj4s );
        itemList2.setPuntuacion(400);
        itemList2.setPrecio(600);
        itemList2.setFechaFin("23/05/2021");

        ItemList itemList3 = new ItemList("Pantalon blanco", "Pantalón dockers blanco", R.drawable.ssj_blues);
        itemList3.setPuntuacion(2000);
        itemList3.setPrecio(400);
        itemList3.setFechaFin("23/05/2021");

        ItemList itemList4 = new ItemList("Lentes de sol", "Lentes de sol grandes", R.drawable.ultrainsitinto);
        itemList4.setPuntuacion(2200);
        itemList4.setPrecio(4001);
        itemList4.setFechaFin("23/05/2021");

        ItemList itemList5 = new ItemList("Cacahuates", "Cacahuates con sal", R.drawable.ssj_blues);
        itemList5.setPuntuacion(15);
        itemList5.setPrecio(10);
        itemList5.setFechaFin("23/05/2021");

        ItemList itemList6 = new ItemList("Chetos", "Chetos flaming hot", R.drawable.ultrainsitinto);
        itemList6.setPuntuacion(40);
        itemList6.setPrecio(11);
        itemList6.setFechaFin("23/05/2021");

        ItemList itemList7 = new ItemList("gorra", "gorra no hay pa otra", R.drawable.ultrainsitinto);
        itemList7.setPuntuacion(2200);
        itemList7.setPrecio(4001);
        itemList7.setFechaFin("23/05/2021");

        ItemList itemList10 = new ItemList("kakalas", "kakalas con esquite", R.drawable.ultrainsitinto);
        itemList10.setPuntuacion(2200);
        itemList10.setPrecio(4001);
        itemList10.setFechaFin("23/05/2021");

        ItemList itemList8 = new ItemList("cerveza", "chelas bien frías", R.drawable.ultrainsitinto);
        itemList8.setPuntuacion(2200);
        itemList8.setPrecio(4001);
        itemList8.setFechaFin("23/05/2021");

        ItemList itemList9 = new ItemList("Oregano", "Oregano para el picadillo", R.drawable.ultrainsitinto);
        itemList9.setPuntuacion(2200);
        itemList9.setPrecio(4001);
        itemList9.setFechaFin("23/05/2021");

        itemLists.add(itemList1);
        itemLists.add(itemList2);
        itemLists.add(itemList3);
        itemLists.add(itemList4);
        itemLists.add(itemList5);
        itemLists.add(itemList6);
        itemLists.add(itemList7);
        itemLists.add(itemList8);
        itemLists.add(itemList9);
        itemLists.add(itemList10);

        
        return itemLists;
    }

    @Override
    public void itemClick(ItemList item) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra("itemDetail", item);
        startActivity(intent);
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        adapter.filter(newText);
        return false;
    }
}
